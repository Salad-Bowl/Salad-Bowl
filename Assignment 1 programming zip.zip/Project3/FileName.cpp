////#include <stdio.h>
////#include <tchar.h>
////#include <string>
////#include <conio.h>
////#include <iostream>
////#include <string.h>
////
////using namespace std;
////
////const string RED = "\033[31m";
////const string GREEN = "\033[32m";
////const string YELLOW = "\033[93m";
////const string RESET = "\033[0m";
////
////enum type { Normal, Fire, Water, Grass, Electric, Ice, Fighting, Poison, Ground, Flying, Psychic, Bug, Rock, Ghost, Dragon, Dark, Steel, Fairy };
////
////int main() {
////    string type;
////	cout << "enter a pokemon type: " << endl;
////	cin >> type;
////	if (type.empty()) {
////		switch (type[18]) {
////		case Normal:
////			cout << RED << "Normal is weak to: Fighting - super effective against: Nothing - immune to: Ghost" << endl;
////				break;
////		case Fire:
////			cout << RED << "Fire is weak to: Water, Ground & Rock - super effective against: Grass, Ice, Bug & Steel - immune to: Nothing" << endl;
////				break;
////		case Water:
////			cout << RED << "Water is weak to: Grass & Electric - super effective against: Fire, Ground, Rock - immune to: Nothing" << endl;
////				break;
////		case Grass:
////			cout << RED << "Grass is weak to: Fire, Ice, Poison, Flying & Bug - super effective against: Water, Ground & Rock - immune to: Nothing" << endl;
////				break;
////		case Electric:
////			cout << RED << "Electric is weak to: Ground - super effective against: Water & Flying - immune to: Nothing" << endl;
////				break;
////		case Ice:
////			cout << RED << "Ice is weak to: Fire, Fighting, Rock & Steel - super effective against: Grass, Ground, Flying & Rock - immune to: Nothing" << endl;
////				break;
////		case Fighting:
////			cout << RED << "Fighting is weak to: Flying, Psychic & Fairy - super effective against: Normal, Ice, Rock, Dark & Steel - immune to: Nothing" << endl;
////				break;
////		case Poison:
////			cout << RED << "Poison is weak to: Ground & Psychic - super effective against: Grass & Fairy - immune to: Nothing" << endl;
////				break;
////		case Ground:
////			cout << RED << "Ground is weak to: Water, Grass & Ice - super effective against: Fire, Electric, Poison, Rock & Steel - immune to: Electric" << endl;
////				break;
////		case Flying:
////			cout << RED << "Flying is weak to: Electric, Ice & Rock - super effective against: Grass, Fighting & Bug - immune to: Ground" << endl;
////				break;
////		case Psychic:
////			cout << RED << "Psychic is weak to: Bug, Ghost & Dark - super effective against: Fighting & Poison - immune to: Nothing" << endl;
////				break;
////		case Bug:
////			cout << RED << "Bug is weak to: Fire, Flying & Rock - super effective against: Grass, Psychic & Dark - immune to: Nothing" << endl;
////				break;
////		case Rock:
////			cout << RED << "Rock is weak to: Water, Grass, Fighting, Ground & Steel - super effective against: Fire, Ice, Flying & Bug - immune to: Nothing" << endl;
////				break;
////		case Ghost:
////			cout << RED << "Ghost is weak to: Ghost & Dark - super effective against: Ghost & Psychic - immune to: Normal & Fighting" << endl;
////				break;
////		case Dragon:
////			cout << RED << "Dragon is weak to: Ice, Dragon & Fairy - super effective against: Dragon - immune to: Nothing" << endl;
////				break;
////		case Dark:
////			cout << RED << "Dark is weak to: Fighting, Bug & Fairy - super effective against: Ghost & Psychic - immune to: Psychic" << endl;
////				break;
////		case Steel:
////			cout << RED << "Steel is weak to: Fire, Fighting & Ground - super effective against : Ice, Rock & Fairy - immune to: Poison" << endl;
////				break;
////		case Fairy:
////			cout << RED << "Fairy is weak to: Poison & Steel." << type << GREEN << "is super effective against: Fighting, Dragon & Dark" << type << YELLOW << "is immune to : Dragon" << RESET << endl;
////				break;
////		}
////	}
////	else;
////	cout << "invalid input for a pokemon type" << endl;
////}
//
//
////#include <stdio.h>
////#include <tchar.h>
////#include <string>
////#include <conio.h>
////#include <iostream>
////#include <string.h>
////#include <algorithm>
////
////     using namespace std;
////
////const string RED = "\033[31m";
////const string GREEN = "\033[32m";
////const string YELLOW = "\033[93m";
////const string RESET = "\033[0m";
////
////int main() {
////    string type;
////    cout << "enter a pokemon type: " << endl;
////    cin >> type;
////    for (auto& c : type) c = tolower(c);
////    if (type == "normal") {
////        cout << RED << "Normal is weak to: Fighting, " << GREEN << "Normal is super effective against: Nothing" << YELLOW << " and Normal is immune to: Ghost" << RESET << endl;
////    }
////    else if (type == "fire") {
////        cout << RED << "Fire is weak to: Water, Ground & Rock - super effective against: Grass, Ice, Bug & Steel - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "water") {
////        cout << RED << "Water is weak to: Grass & Electric - super effective against: Fire, Ground, Rock - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "grass") {
////        cout << RED << "Grass is weak to: Fire, Ice, Poison, Flying & Bug - super effective against: Water, Ground & Rock - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "electric") {
////        cout << RED << "Electric is weak to: Ground - super effective against: Water & Flying - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "ice") {
////        cout << RED << "Ice is weak to: Fire, Fighting, Rock & Steel - super effective against: Grass, Ground, Flying & Dragon - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "fighting") {
////        cout << RED << "Fighting is weak to: Flying, Psychic & Fairy - super effective against: Normal, Ice, Rock, Dark & Steel - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "poison") {
////        cout << RED << "Poison is weak to: Ground & Psychic - super effective against: Grass & Fairy - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "ground") {
////        cout << RED << "Ground is weak to: Water, Grass & Ice - super effective against: Fire, Electric, Poison, Rock & Steel - immune to: Electric" << RESET << endl;
////    }
////    else if (type == "flying") {
////        cout << RED << "Flying is weak to: Electric, Ice & Rock - super effective against: Grass, Fighting & Bug - immune to: Ground" << RESET << endl;
////    }
////    else if (type == "psychic") {
////        cout << RED << "Psychic is weak to: Bug, Ghost & Dark - super effective against: Fighting & Poison - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "bug") {
////        cout << RED << "Bug is weak to: Fire, Flying & Rock - super effective against: Grass, Psychic & Dark - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "rock") {
////        cout << RED << "Rock is weak to: Water, Grass, Fighting, Ground & Steel - super effective against: Fire, Ice, Flying & Bug - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "ghost") {
////        cout << RED << "Ghost is weak to: Ghost & Dark -" << RESET << endl;
////    }
////    else if (type == "dragon") {
////        cout << RED << "Dragon is weak to: Ice, Dragon & Fairy - super effective against: Dragon - immune to: Nothing" << RESET << endl;
////    }
////    else if (type == "dark") {
////        cout << RED << "Dark is weak to: Fighting, Bug & Fairy - super effective against: Ghost & Psychic - immune to: Psychic" << RESET << endl;
////    }
////    else if (type == "steel") {
////        cout << RED << "Steel is weak to: Fire, Fighting & Ground - super effective against: Ice, Rock & Fairy - immune to: Poison" << RESET << endl;
////    }
////    else if (type == "fairy") {
////        cout << RED << "Fairy is weak to: Poison & Steel, " << GREEN << "Fairy is super effective against: Fighting, Dragon & Dark" << YELLOW << " and Fairy is immune to: Dragon" << RESET << endl;
////    }
////    else {
////        cout << RED << type << " is invalid input for a Pokemon type." << endl;
////    }
////    return 0;
////} 
//
//
//#include <stdio.h>
//#include <tchar.h>
//#include <conio.h>
//#include <string>
//#include <iostream>
//#include <fstream>
//#include <sstream>
//#include <string.h>
//#include <algorithm>
//
//using namespace std;
//
//const string RED = "\033[31m"; // This line and the three lines below it are used to allow the calling of colours in future parts of the code, allowing 
//const string GREEN = "\033[32m";
//const string YELLOW = "\033[93m";
//const string RESET = "\033[0m";
//
//int main() {
//    string type;
//    cout << "Enter a Pokemon type for its weaknesses, strengths and immunities:  " << endl;
//    cin >> type;
//    string filepath = "H:\\Documents\\Projects\\PKMNtype.txt"; // This line and the two below it allow anything prefaced with "file" to be sent to a document in that given path
//    ofstream file(filepath, ios::app);
//    if (file.is_open()) {
//        for (auto& c : type) c = tolower(c); // This line turns any capital letter character into its lower case counterpart to ensure that both forms are accepted
//        // This block of code below is the collection of information that will be parroted to the user depending on the input given
//        if (type == "normal") {
//            cout << RED << "Normal is weak to: Fighting, " << GREEN << "super effective against: Nothing, " << YELLOW << "and immune to: Ghost" << RESET << endl;
//            file << "Normal is weak to: Fighting, super effective against: Nothing, and immune to: Ghost" << endl;
//        }
//        else if (type == "fire") {
//            cout << RED << "Fire is weak to: Water, Ground & Rock, " << GREEN << "super effective against: Grass, Ice, Bug & Steel, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Fire is weak to: Water, Ground & Rock, super effective against: Grass, Ice, Bug & Steel, and immune to: Nothing" << endl;
//        }
//        else if (type == "water") {
//            cout << RED << "Water is weak to: Grass & Electric, " << GREEN << "super effective against: Fire, Ground, Rock, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Water is weak to: Grass & Electric, super effective against: Fire, Ground & Rock, and immune to: Nothing" << endl;
//        }
//        else if (type == "grass") {
//            cout << RED << "Grass is weak to: Fire, Ice, Poison, Flying & Bug, " << GREEN << "super effective against: Water, Ground & Rock, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Grass is weak to: Fire, Ice, Poison, Flying & Bug, super effective against: Water, Ground & Rock, and immune to: Nothing" << endl;
//        }
//        else if (type == "electric") {
//            cout << RED << "Electric is weak to: Ground, " << GREEN << "super effective against: Water & Flying, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Electric is weak to: Ground, super effective against: Water & Flying, and immune to: Nothing" << endl;
//        }
//        else if (type == "ice") {
//            cout << RED << "Ice is weak to: Fire, Fighting, Rock & Steel, " << GREEN << "super effective against: Grass, Ground, Flying & Dragon, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Ice is weak to: Fire, Fighting, Rock & Steel, super effective against: Grass, Ground, Flying & Dragon, and immune to: Nothing" << endl;
//        }
//        else if (type == "fighting") {
//            cout << RED << "Fighting is weak to: Flying, Psychic & Fairy, " << GREEN << "super effective against: Normal, Ice, Rock, Dark & Steel, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Fighting is weak to: Flying, Psychic & Fairy, super effective against: Normal, Ice, Rock, Dark & Steel, and immune to: Nothing" << endl;
//        }
//        else if (type == "poison") {
//            cout << RED << "Poison is weak to: Ground & Psychic, " << GREEN << "super effective against: Grass & Fairy, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Poison is weak to: Ground & Psychic, super effective against: Grass & Fairy, and immune to: Nothing" << endl;
//        }
//        else if (type == "ground") {
//            cout << RED << "Ground is weak to: Water, Grass & Ice, " << GREEN << "super effective against: Fire, Electric, Poison, Rock & Steel, " << YELLOW << "and immune to: Electric" << RESET << endl;
//            file << "Ground is weak to: Water, Grass & Ice, super effective against: Fire, Electric, Poison, Rock & Steel, and immune to: Electric" << endl;
//        }
//        else if (type == "flying") {
//            cout << RED << "Flying is weak to: Electric, Ice & Rock, " << GREEN << "super effective against: Grass, Fighting & Bug, " << YELLOW << "and immune to: Ground" << RESET << endl;
//            file << "Flying is weak to: Electric, Ice & Rock, super effective against: Grass, Fighting & Bug, and immune to: Ground" << endl;
//        }
//        else if (type == "psychic") {
//            cout << RED << "Psychic is weak to: Bug, Ghost & Dark, " << GREEN << "super effective against: Fighting & Poison, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Psychic is weak to: Bug, Ghost & Dark, super effective against: Fighting & Poison, and immune to: Nothing" << endl;
//        }
//        else if (type == "bug") {
//            cout << RED << "Bug is weak to: Fire, Flying & Rock, " << GREEN << "super effective against: Grass, Psychic & Dark, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Bug is weak to: Fire, Flying & Rock, super effective against: Grass, Psychic & Dark, and immune to: Nothing" << endl;
//        }
//        else if (type == "rock") {
//            cout << RED << "Rock is weak to: Water, Grass, Fighting, Ground & Steel, " << GREEN << "super effective against: Fire, Ice, Flying & Bug, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Rock is weak to: Water, Grass, Fighting, Ground & Steel, super effective against: Fire, Ice, Flying & Bug, and immune to: Nothing" << endl;
//        }
//        else if (type == "ghost") {
//            cout << RED << "Ghost is weak to: Ghost & Dark, " << GREEN << "super effective against: Psychic & Ghost, " << YELLOW << "and immune to: Normal & Fighting" << RESET << endl;
//            file << "Ghost is weak to: Ghost & Dark, super effective against: Psychic & Ghost, and immune to: Normal & Fighting" << endl;
//        }
//        else if (type == "dragon") {
//            cout << RED << "Dragon is weak to: Ice, Dragon & Fairy, " << GREEN << "super effective against: Dragon, " << YELLOW << "and immune to: Nothing" << RESET << endl;
//            file << "Dragon is weak to: Ice, Dragon & Fairy, super effective against: Dragon, and immune to: Nothing" << endl;
//        }
//        else if (type == "dark") {
//            cout << RED << "Dark is weak to: Fighting, Bug & Fairy, " << GREEN << "super effective against: Ghost & Psychic, " << YELLOW << "and immune to: Psychic" << RESET << endl;
//            file << "Dark is weak to: Fighting, Bug & Fairy, super effective against: Ghost & Psychic, and immune to: Psychic" << endl;
//        }
//        else if (type == "steel") {
//            cout << RED << "Steel is weak to: Fire, Fighting & Ground, " << GREEN << "super effective against: Ice, Rock & Fairy, " << YELLOW << "and immune to: Poison" << RESET << endl;
//            file << "Steel is weak to: Fire, Fighting & Ground, super effective against: Ice, Rock & Fairy, and immune to: Poison" << endl;
//        }
//        else if (type == "fairy") {
//            cout << RED << "Fairy is weak to: Poison & Steel, " << GREEN << "super effective against: Fighting, Dragon & Dark, " << YELLOW << "and immune to: Dragon" << RESET << endl;
//            file << "Fairy is weak to: Poison & Steel, super effective against: Fighting, Dragon & Dark, and immune to: Dragon" << endl;
//        }
//        // Debugging this code by using breakpoints with "break;" allowed troubleshooting the code a single line at a time to figure out what was broken and needed fixing
//        else {
//            cout << RED << type << " is invalid input for a Pok�mon type." << RESET << endl;
//            file << type << " is invalid input for a Pok�mon type." << endl;
//        }
//    }   else {
//        cout << "file failed to open" << endl;
//    return 0;
//    }
//}

#include <stdio.h> // These lines include libraries to hold information to be used by the code, allowing it to function
#include <tchar.h>
#include <conio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <algorithm>

using namespace std; // This line tells the code to use C++ standard for everything from here onwards

const string RED = "\033[31m"; // This line and the three lines below it are used to allow the calling of colours in future parts of the code, allowing 
const string GREEN = "\033[32m";
const string YELLOW = "\033[93m";
const string RESET = "\033[0m";

int main() {
    string type;
    cout << "Enter a Pokemon type for its weaknesses, strengths and immunities:  " << endl;
    cin >> type;
    string filepath = "H:\\Documents\\Projects\\PKMNtype.txt"; // This line and the two below it allow anything prefaced with "file" to be sent to a document in that given path
    ofstream file(filepath, ios::app);
    if (file.is_open()) { // Checks to see if the file is open
        for (auto& c : type) c = tolower(c); // This line turns any capital letter character into its lower case counterpart to ensure that both forms are accepted
        // This block of code below is the collection of information that will be parroted to the user depending on the input given
        if (type == "normal") {
            cout << RED << "Normal is weak to: Fighting, " << GREEN << "super effective against: Nothing, " << YELLOW << "and immune to: Ghost" << RESET << endl;
            file << "Normal is weak to: Fighting, super effective against: Nothing, and immune to: Ghost" << endl;
        }
        else if (type == "fire") {
            cout << RED << "Fire is weak to: Water, Ground & Rock, " << GREEN << "super effective against: Grass, Ice, Bug & Steel, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Fire is weak to: Water, Ground & Rock, super effective" << endl;
        }
        else if (type == "water") {
            cout << RED << "Water is weak to: Grass & Electric, " << GREEN << "super effective against: Fire, Ground, Rock, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Water is weak to: Grass & Electric, super effective against: Fire, Ground & Rock, and immune to: Nothing" << endl;
        }
        else if (type == "grass") {
            cout << RED << "Grass is weak to: Fire, Ice, Poison, Flying & Bug, " << GREEN << "super effective against: Water, Ground & Rock, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Grass is weak to: Fire, Ice, Poison, Flying & Bug, super effective against: Water, Ground & Rock, and immune to: Nothing" << endl;
        }
        else if (type == "electric") {
            cout << RED << "Electric is weak to: Ground, " << GREEN << "super effective against: Water & Flying, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Electric is weak to: Ground, super effective against: Water & Flying, and immune to: Nothing" << endl;
        }
        else if (type == "ice") {
            cout << RED << "Ice is weak to: Fire, Fighting, Rock & Steel, " << GREEN << "super effective against: Grass, Ground, Flying & Dragon, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Ice is weak to: Fire, Fighting, Rock & Steel, super effective against: Grass, Ground, Flying & Dragon, and immune to: Nothing" << endl;
        }
        else if (type == "fighting") {
            cout << RED << "Fighting is weak to: Flying, Psychic & Fairy, " << GREEN << "super effective against: Normal, Ice, Rock, Dark & Steel, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Fighting is weak to: Flying, Psychic & Fairy, super effective against: Normal, Ice, Rock, Dark & Steel, and immune to: Nothing" << endl;
        }
        else if (type == "poison") {
            cout << RED << "Poison is weak to: Ground & Psychic, " << GREEN << "super effective against: Grass & Fairy, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Poison is weak to: Ground & Psychic, super effective against: Grass & Fairy, and immune to: Nothing" << endl;
        }
        else if (type == "ground") {
            cout << RED << "Ground is weak to: Water, Grass & Ice, " << GREEN << "super effective against: Fire, Electric, Poison, Rock & Steel, " << YELLOW << "and immune to: Electric" << RESET << endl;
            file << "Ground is weak to: Water, Grass & Ice, super effective against: Fire, Electric, Poison, Rock & Steel, and immune to: Electric" << endl;
        }
        else if (type == "flying") {
            cout << RED << "Flying is weak to: Electric, Ice & Rock, " << GREEN << "super effective against: Grass, Fighting & Bug, " << YELLOW << "and immune to: Ground" << RESET << endl;
            file << "Flying is weak to: Electric, Ice & Rock, super effective against: Grass, Fighting & Bug, and immune to: Ground" << endl;
        }
        else if (type == "psychic") {
            cout << RED << "Psychic is weak to: Bug, Ghost & Dark, " << GREEN << "super effective against: Fighting & Poison, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Psychic is weak to: Bug, Ghost & Dark, super effective against: Fighting & Poison, and immune to: Nothing" << endl;
        }
        else if (type == "bug") {
            cout << RED << "Bug is weak to: Fire, Flying & Rock, " << GREEN << "super effective against: Grass, Psychic & Dark, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Bug is weak to: Fire, Flying & Rock, super effective against: Grass, Psychic & Dark, and immune to: Nothing" << endl;
        }
        else if (type == "rock") {
            cout << RED << "Rock is weak to: Water, Grass, Fighting, Ground & Steel, " << GREEN << "super effective against: Fire, Ice, Flying & Bug, " << YELLOW << "and immune to: Nothing" << RESET << endl;
            file << "Rock is weak to: Water, Grass, Fighting, Ground & Steel, super effective against: Fire, Ice, Flying & Bug, and immune to: Nothing" << endl;
        }
        else if (type == "ghost") {
            cout << RED << "Ghost is weak to: Ghost & Dark, " << GREEN << "super effective against: Psychic & Ghost, " << YELLOW << "and immune to: Normal & Fighting" << RESET << endl;
            file << "Ghost is weak to: Ghost & Dark, super effective against: Psychic & Ghost, and immune to: Normal & Fighting" << endl;
        }
        else if (type == "dragon") {
            cout << RED << "Dragon is weak to: Ice, Dragon & Fairy, " << GREEN << "super effective against : Dragon, " << YELLOW << " and immune to : Nothing" << RESET << endl;
            file << "Dragon is weak to: Ice, Dragon & Fairy, super effective against: Dragon, and immune to: Nothing" << endl;
        }
        else if (type == "dark") {
            cout << RED << "Dark is weak to: Fighting, Bug & Fairy, " << GREEN << "super effective against: Ghost & Psychic, " << YELLOW << "and immune to: Psychic" << RESET << endl;
            file << "Dark is weak to: Fighting, Bug & Fairy, super effective against: Ghost & Psychic, and immune to: Psychic" << endl;
        }
        else if (type == "steel") {
            cout << RED << "Steel is weak to: Fire, Fighting & Ground, " << GREEN << "super effective against: Ice, Rock & Fairy, " << YELLOW << "and immune to: Poison" << RESET << endl;
            file << "Steel is weak to: Fire, Fighting & Ground, super effective against: Ice, Rock & Fairy, and immune to: Poison" << endl;
        }
        else if (type == "fairy") {
            cout << RED << "Fairy is weak to: Poison & Steel, " << GREEN << "super effective against: Fighting, Dragon & Dark, " << YELLOW << "and immune to: Dragon" << RESET << endl;
            file << "Fairy is weak to: Poison & Steel, super effective against: Fighting, Dragon & Dark, and immune to: Dragon" << endl;
        }
        else {
            cout << RED << type << " is an invalid input for a Pokemon type" << RESET << endl; // validation to let the user know that input is invalid
        }
        return 0;
        }
    }